def main():
    ascii = [66, 79, 78, 74, 79, 86, 73]

    for c in ascii:
        print(chr(c), end='')


if __name__ == '__main__':
    main()
